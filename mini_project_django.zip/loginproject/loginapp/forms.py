from django.contrib.auth.forms import UserCreationForm 
import django.contrib.auth 
from django import forms
from .models import roombooking
from django.forms import widgets

User=django.contrib.auth.get_user_model() 
class RegisterForm(UserCreationForm): 
    class Meta: 
        model=User 
        fields=['username','email','password1','password2']

class customerForm(forms.ModelForm):
    class Meta:
        model=roombooking
        fields='__all__'        
        widgets = {
            'checkin': widgets.DateInput(attrs={'type': 'date'}),
            'checkout': widgets.DateInput(attrs={'type': 'date'})
        }        