from django.db.models.base import Model
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from .forms import RegisterForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import roombooking
from .forms import customerForm

@login_required(login_url='login')

def homepage9(request): 
    emp=roombooking.objects.all() 
    return render(request,'index.html',{'emp':emp})

def homepage8(request): 
    return render(request,'membership.html')

def homepage7(request,id=0):
    if request.method == "GET":  
        if id==0:
            form = customerForm()  
        else:
            emp=roombooking.objects.get(id=id)
            form = customerForm(instance=emp) 
        return render(request,"reservation.html",{'form':form})
    else:
        if id==0:  
            form = customerForm(request.POST)
        else:
            emp=roombooking.objects.get(id=id)
            form = customerForm(request.POST,instance=emp)   
        if form.is_valid():  
            form.save()  
        return redirect('/') 

def delete(request, id):  
    emp = roombooking.objects.get(id=id)  
    emp.delete()  
    return redirect('/')  

def homepage6(request): 
    return render(request,'laketahoe.html')

def homepage5(request): 
    return render(request,'shop.html')

def homepage4(request): 
    return render(request,'weddings.html')

def homepage3(request): 
    return render(request,'menues.html')

def homepage2(request): 
    return render(request,'thelodge.html')

def homepage(request): 
    return render(request,'home.html')

def logoutpage(request): 
    logout(request)
    return redirect('login')

def registerpage(request): 
    form=RegisterForm() 
    if request.method=='POST': 
        form=RegisterForm(request.POST) 
        if form.is_valid(): 
            form.save() 
            uname=request.POST['username'] 
            messages.success(request,'Account created Successfully for '+uname) 
            return redirect('login') 
        
    return render(request,'register.html',{'form':form})

def loginpage(request): 
    if request.method=='POST': 
        username=request.POST['username'] 
        password=request.POST['password'] 
        user=authenticate(request,username=username,password=password) 
        print(user) 
        if user is not None: 
          login(request,user) 
          return redirect('home') 
        else: 
            messages.info(request,'User Name or Password Incorrect') 
        
    return render(request,'login.html')


# Create your views here.
