from django.contrib import admin
from loginapp.models import roombooking 
from .models import roombooking
admin.site.register(roombooking)

# Register your models here.
