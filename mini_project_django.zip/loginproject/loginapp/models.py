from django.db import models
# Create your models here. 
# #Each model is a Python class that subclasses django.db.models.Model. 
class roombooking(models.Model): 
    fname=models.CharField(max_length=30)  
    lname=models.CharField(max_length=30) 
    checkin=models.DateField(null=True,blank=True)
    checkout=models.DateField(null=True,blank=True)
    email=models.EmailField(max_length=50) 
    password=models.CharField(max_length=50)
    address=models.CharField(max_length=60) 
    address2=models.CharField(max_length=60) 
    city=models.CharField(max_length=50)
    state=models.CharField(max_length=50)
    zip=models.CharField(max_length=60) 
    noofperson=models.IntegerField( )  
    typeofroom=models.CharField(max_length=50)

# Create your models here.
